rm -rf /home/ubuntu/test-web-server
mkdir /home/ubuntu/test-web-server
cp -f ./*.txt /home/ubuntu/test-web-server/
cat /home/ubuntu/test-web-server/456.txt
